package com.example.quizproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
